package com.crossover.e2e;

import java.io.File;
import java.io.FileReader;
import java.util.Collections;
import java.util.List;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import junit.framework.TestCase;
import org.junit.Test;
import org.openqa.selenium.*;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;


public class GMailTest extends TestCase {
    private WebDriver driver;
    private Properties properties = new Properties();

    public void setUp() throws Exception {
        
        properties.load(new FileReader(new File("src/test/resources/test.properties")));
        
        //Dont Change below line. Set this value in test.properties file incase you need to change it..
        System.setProperty("webdriver.chrome.driver",properties.getProperty("webdriver.chrome.driver") );
        
        
        ChromeOptions options = new ChromeOptions(); 
        options.setExperimentalOption("useAutomationExtension", false);
        options.setExperimentalOption("excludeSwitches",Collections.singletonList("enable-automation"));  
        driver = new ChromeDriver(options);
        driver.manage().window().maximize();
   
    	}
       
    

    public void tearDown() throws Exception {
        driver.quit();
    }

    /*
     * Please focus on completing the task
     * 
     */
    @Test
    public void testSendEmail() throws Exception {
        driver.get("https://mail.google.com/");
       
        // Enter User name
        WebElement userElement = driver.findElement(By.id("identifierId"));
        userElement.sendKeys(properties.getProperty("username"));

        driver.findElement(By.id("identifierNext")).click();

        Thread.sleep(1000);
        
        // Enter Password
        WebElement passwordElement = driver.findElement(By.name("password"));
        passwordElement.sendKeys(properties.getProperty("password"));
        
        // Login to the gmail
        driver.findElement(By.id("passwordNext")).click();
        
        
        driver.manage().timeouts().implicitlyWait(90, TimeUnit.SECONDS);
   //   Thread.sleep(9000);

        // Composing mail
        WebElement composeElement = driver.findElement(By.xpath("//*[@role='button' and contains(text(),'Compose')]"));
        composeElement.click();

        // Enter the recipient name
        driver.findElement(By.name("to")).clear();
        driver.findElement(By.name("to")).sendKeys(String.format("%s@gmail.com", properties.getProperty("username")));
        
        
        // emailSubject and emailbody to be used in this unit test. 
        String emailSubject = properties.getProperty("email.subject");
        String emailBody = properties.getProperty("email.body"); 
        
        // Enter the Subject of email
        WebElement subject = driver.findElement(By.xpath("//input[@name='subjectbox']"));
        subject.sendKeys(emailSubject);
        
        // Enter the Message body
        WebElement body = driver.findElement(By.xpath("//div[@aria-label='Message Body']"));
        body.sendKeys(emailBody);
        
        // Click on More option to enter label
        driver.findElement(By.xpath("//div[@aria-label='More options']")).click();
        
        driver.findElement(By.xpath("//div[contains(text(),'Label')]")).click();
      
        // Select label as social
        WebElement label = driver.findElement(By.xpath("//input[@ignoreesc='true']"));
        Thread.sleep(3000);
        		label.sendKeys("Social");
        		label.sendKeys(Keys.ENTER);
        
        // Send the composed mail		
        driver.findElement(By.xpath("//*[@role='button' and text()='Send']")).click();
        
        // Navigate to Social label under inbox
        driver.findElement(By.xpath("//div[contains(text(),'Social')]")).click();
        	Thread.sleep(3000);
                
       // Wait for the email to arrive in the inbox with above code and then Store all the mail in the list with below code
       List<WebElement> inboxEmails = driver.findElements(By.xpath("//*[@role='row']"));                   

       // Open the received email with the subject which was used to compose mail
        for(WebElement email : inboxEmails){                                                                                                                           
            if(email.isDisplayed() && email.getText().contains(emailSubject)){                                                                                                                                   
                
            	email.click();    
                
            	// Mark email as starred
                driver.findElement(By.xpath("//span[@class='T-KT']")).click();
                
                //To verify email came under proper Label i.e. "Social"
	                boolean present1;
	        		try {
	        		   driver.findElement(By.xpath("//div[@title='Search for all messages with label Social']"));
	        		   present1 = true;
	        		} catch (NoSuchElementException e) {
	        		   present1 = false;
	        		}
                
	            		if(present1){
	            			System.out.println("email came under proper Label i.e. Social ");
	            		}
	            		else{
	
	            			System.out.println("email did not came under Social Label ");
	
	            			}

	       		//To verify the subject 
            		boolean present2;
            		try {
            		   driver.findElement(By.xpath("//h2[contains(text(),'Subject of this message')]"));
            		   present2 = true;
            		} catch (NoSuchElementException e) {
            		   present2 = false;
            		}
            		
	            		if(present2) {
	            			System.out.println("Subject of the recieved mail is as mentioned in src/test/resources/test.properties ");
	            		}
	            		else{
	
	            			System.out.println("Subject of the recieved mail is not as mentioned in src/test/resources/test.properties  ");
	
	            			}
            		
	            //To verify the message body
            		boolean present3;
            		try {
            		   driver.findElement(By.xpath("//h2[contains(text(),'Subject of this message')]"));
            		   present3 = true;
            		} catch (NoSuchElementException e) {
            		   present3 = false;
            		}

            		
	            		if(present3){
	            			System.out.println("Body of the recieved mail is as mentioned in src/test/resources/test.properties");
	            		}
	            		else{
	
	            			System.out.println("Body of the recieved mail is as mentioned in src/test/resources/test.properties");
	
	            			}

            }                                                                                                                                                          
        } 
      
        
    }
}
