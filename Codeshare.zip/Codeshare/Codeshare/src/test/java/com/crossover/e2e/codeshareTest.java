package com.crossover.e2e;

import java.io.File;
import java.io.FileReader;
import java.util.Collections;
import java.util.Properties;
import junit.framework.TestCase;
import org.junit.Test;
import org.openqa.selenium.*;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;


public class codeshareTest extends TestCase {
    private WebDriver driver;
    private Properties properties = new Properties();

    public void setUp() throws Exception {
        
        properties.load(new FileReader(new File("src/test/resources/test.properties")));
        
        //Dont Change below line. Set this value in test.properties file incase you need to change it..
        System.setProperty("webdriver.chrome.driver",properties.getProperty("webdriver.chrome.driver") );
        
        
        ChromeOptions options = new ChromeOptions(); 
        options.setExperimentalOption("useAutomationExtension", false);
        options.setExperimentalOption("excludeSwitches",Collections.singletonList("enable-automation"));  
        driver = new ChromeDriver(options);
        driver.manage().window().maximize();
   
    	}
       
    

    public void tearDown() throws Exception {
        driver.quit();
    }

    
    @Test
    public void testSendEmail() throws Exception {
        driver.get("https://codeshare.io/");
        Thread.sleep(6000);
        
       WebElement signup =  driver.findElement(By.xpath("//a[contains(text(),'Sign Up')]"));
       signup.sendKeys(Keys.ENTER); 
       Thread.sleep(2000);
 
      WebElement userElement = driver.findElement(By.name("name"));
      userElement.sendKeys(properties.getProperty("username"));
      
      WebElement Email = driver.findElement(By.name("email"));
      Email.sendKeys(properties.getProperty("email"));
      
      WebElement passwordElement = driver.findElement(By.name("password"));
      passwordElement.sendKeys(properties.getProperty("password"));
      
      driver.findElement(By.xpath("//button[@type='submit' and contains(text(),'Sign up')]")).click(); ;
      Thread.sleep(5000);
      
      boolean present;
  
		try {
		   driver.findElement(By.xpath("//*[@id=\"codeshare\"]/header/div/div[2]/ul/li[2]/a/text()"));
		   present = true;
		} catch (NoSuchElementException e) {
		   present = false;
		}
		
  		if(present){
  			System.out.println("User logged into the system and full name in the right top corner");
  		}
  		else{

  			System.out.println("User logged into the system and full name in the right top corner");

  			}

      
        
    }
}
