# Test Scenario
What is the user interaction sequence to be performed by a user to accomplish the business goal?
What is the expected outcome from the system for each user interaction sequence performed by the user?
(Please note that the user interaction sequence should elicit a system response and not a mere browser response to an HTML event.)
"		
#	User Interaction sequence	and Expected outcome
1	Open Codeshare -	Expect the page to be shown
2	Click the "Sign up" link -	Expect the page "https://codeshare.io/register" to be open
3	Fill in the fields "Your full name", "Email address" and "Password" with your data. - Expect the fields populated with the texts
4	Click "Sign up" button	- Expect to be logged into the system and your full name in the right top corner

# Prerequisites:
- ChromeDriver 2.44 , JDK 8+
- Any IDE

# Development Environment:
- Modify src/test/resources/test.properties to point to ChromeDriver's path on your system
- On any terminal, move to the project's root folder and execute the following command:
    - ./gradlew clean test

# How to run:
Change the username, emailid and password field in src/test/resources/test.properties and then run